import pickle
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc, precision_recall_fscore_support
import numpy as np

# Chargement du fichier
file_path = "demoloader/trained_model/stl10_meminf_attack0.p"

with open(file_path, "rb") as f:
    y_true, y_pred, y_scores = pickle.load(f)

# Affichage basique
print(f"Nombre d\'échantillons : {len(y_true)}")
print(f"Exemple de labels réels : {y_true[:10]}")
print(f"Exemple de prédictions attack_model : {y_pred[:10]}")
print(f"Exemple de scores attack_model : {y_scores[:10]}")

# Calcul de la courbe ROC et de l'AUC
fpr, tpr, thresholds = roc_curve(y_true, y_scores)
roc_auc = auc(fpr, tpr)

# Courbe ROC
plt.figure(figsize=(8, 6))
plt.plot(fpr, tpr, label=f'Attack Model ROC (AUC = {roc_auc:.2f})')
plt.plot([0, 1], [0, 1], 'k--', label='Random Guess')
plt.xlabel('Taux de Faux Positifs (FPR)')
plt.ylabel('Taux de Vrais Positifs (TPR)')
plt.title('Courbe ROC de l\'Attack Model')
plt.legend(loc='lower right')
plt.grid(True)
plt.savefig("roc_curve.png", dpi=300)
plt.show()

# Calcul du F1-score pour chaque seuil
f1_scores = []
for thresh in thresholds:
    y_pred_thresh = (y_scores >= thresh).astype(int)
    _, _, f1, _ = precision_recall_fscore_support(y_true, y_pred_thresh, average='binary', zero_division=0)
    f1_scores.append(f1)

# Courbe F1-score
plt.figure(figsize=(8, 6))
plt.plot(thresholds, f1_scores, label='F1-score en fonction du seuil')
plt.xlabel('Seuil de décision')
plt.ylabel('F1-score')
plt.title('F1-score selon le seuil de classification')
plt.grid(True)
plt.legend()
plt.savefig("f1_curve.png", dpi=300)
plt.show()

